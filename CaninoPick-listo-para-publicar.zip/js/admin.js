/* ============================================================
 * CaninoPick · admin.js
 * ------------------------------------------------------------
 * Panel de administración del catálogo (data/products.json).
 * Vanilla JS, sin dependencias.
 *
 * Funciones:
 *  - Carga products.json con fetch a ../data/products.json
 *    (con alternativa de subir el archivo si falla la carga).
 *  - Tabla de productos con buscador.
 *  - Crear, editar y eliminar productos (todos los campos del
 *    schema del contrato + campos SEO opcionales).
 *  - Informe "Enlaces de afiliado pendientes".
 *  - Exportar (descarga products.json) e importar (lee archivo).
 *  - Borrador automático en localStorage.
 *
 * Flujo real: editar aquí → Exportar → sustituir data/products.json
 * → python3 build.py → subir dist/.
 * ============================================================ */
(function () {
  'use strict';

  /* ================= 0. Constantes ================= */

  /** Clave del borrador en localStorage. */
  var DRAFT_KEY = 'caninopick_admin_draft_v1';
  /** Marcador que indica un enlace de afiliado sin configurar. */
  var PENDING_MARKER = 'ENLACE_AFILIADO';

  /** Las 15 categorías oficiales (slug → etiqueta). */
  var CATEGORIES = [
    { slug: 'alimentos-para-perros', label: 'Alimentos y premios' },
    { slug: 'camas-para-perros', label: 'Camas' },
    { slug: 'juguetes-para-perros', label: 'Juguetes' },
    { slug: 'arneses-para-perros', label: 'Correas y arneses' },
    { slug: 'comederos-para-perros', label: 'Comederos y bebederos' },
    { slug: 'higiene-para-perros', label: 'Higiene y cuidado' },
    { slug: 'productos-para-cachorros', label: 'Cachorros' },
    { slug: 'casas-y-jaulas-para-perros', label: 'Casas y jaulas' },
    { slug: 'viajar-con-perros', label: 'Viajar' },
    { slug: 'grooming-para-perros', label: 'Grooming' },
    { slug: 'entrenamiento-para-perros', label: 'Entrenamiento' },
    { slug: 'ropa-para-perros', label: 'Ropa y accesorios' },
    { slug: 'cuidado-dental-para-perros', label: 'Cuidado dental' },
    { slug: 'exterior-para-perros', label: 'Exterior' },
    { slug: 'tecnologia-para-mascotas', label: 'Tecnología' }
  ];

  /** Valoraciones editoriales permitidas (solo cualitativas). */
  var VERDICTS = ['', 'Nuestra elección', 'Recomendado', 'Buena opción', 'A considerar'];
  /** Textos de CTA permitidos. */
  var CTAS = ['Ver producto', 'Consultar producto', 'Ver opción recomendada', 'Ver detalles', 'Ver disponibilidad'];
  var SIZES = ['pequeno', 'mediano', 'grande'];
  var AGES = ['cachorro', 'adulto', 'senior'];

  /* ================= 1. Estado y utilidades ================= */

  var state = {
    products: [],
    editingId: null, // null = creando uno nuevo
    filter: ''
  };

  function $(id) {
    return document.getElementById(id);
  }

  /** Escapa HTML para pintar valores con seguridad. */
  function esc(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** Convierte un valor en array de strings limpios. */
  function toStringArray(value) {
    if (Array.isArray(value)) {
      return value.map(function (v) { return String(v).trim(); }).filter(Boolean);
    }
    if (typeof value === 'string' && value.trim()) return [value.trim()];
    return [];
  }

  function categoryLabel(slug) {
    for (var i = 0; i < CATEGORIES.length; i++) {
      if (CATEGORIES[i].slug === slug) return CATEGORIES[i].label;
    }
    return slug || '—';
  }

  /** ¿El enlace de afiliado está pendiente de configurar? */
  function isPending(url) {
    return !url || String(url).indexOf(PENDING_MARKER) !== -1;
  }

  /* ================= 2. Mensajes ================= */

  function showMsg(text, type) {
    var box = $('admin-msg');
    box.hidden = false;
    box.textContent = text;
    box.className = 'msg ' + (type === 'ok' ? 'msg-ok' : type === 'error' ? 'msg-error' : 'msg-info');
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function showFormErrors(errors) {
    var box = $('form-errors');
    if (!errors.length) {
      box.hidden = true;
      box.innerHTML = '';
      return;
    }
    box.hidden = false;
    box.innerHTML = '<strong>Revisa estos campos:</strong><ul><li>' +
      errors.map(esc).join('</li><li>') + '</li></ul>';
    box.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  /* ================= 3. Carga de datos ================= */

  function loadProducts() {
    fetch('../data/products.json')
      .then(function (resp) {
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        return resp.json();
      })
      .then(function (data) {
        if (!Array.isArray(data)) throw new Error('El JSON no contiene un array.');
        state.products = data.map(function (raw) { return normalizeProduct(raw, false); });
        renderAll();
        checkDraft();
      })
      .catch(function (err) {
        // Alternativa: subir el archivo manualmente.
        showMsg(
          'No se pudo cargar ../data/products.json (' + err.message + '). ' +
          'Usa «⤒ Importar products.json» para subir el archivo desde tu equipo y seguir trabajando.',
          'info'
        );
        renderAll();
        checkDraft();
      });
  }

  /**
   * Normaliza un producto al schema del contrato, conservando
   * cualquier campo extra desconocido que traiga el objeto.
   */
  function normalizeProduct(raw, strict) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      throw new Error('elemento no válido');
    }
    var p = {};
    Object.keys(raw).forEach(function (k) { p[k] = raw[k]; });

    p.id = String(raw.id || '').trim();
    p.name = String(raw.name || '').trim();
    if (strict) {
      if (!p.id) throw new Error('falta el campo "id"');
      if (!p.name) throw new Error('falta el campo "name" (id: ' + p.id + ')');
    }
    p.category = String(raw.category || '');
    p.image = String(raw.image || '');
    p.image_alt = String(raw.image_alt || '');
    p.summary = String(raw.summary || '');
    p.features = toStringArray(raw.features);
    p.pros = toStringArray(raw.pros);
    p.cons = toStringArray(raw.cons);
    p.ideal_for = String(raw.ideal_for || '');
    p.dog_size = toStringArray(raw.dog_size).filter(function (v) { return SIZES.indexOf(v) !== -1; });
    p.dog_age = toStringArray(raw.dog_age).filter(function (v) { return AGES.indexOf(v) !== -1; });
    p.verdict = VERDICTS.indexOf(raw.verdict) !== -1 ? raw.verdict : '';
    p.cta = CTAS.indexOf(raw.cta) !== -1 ? raw.cta : 'Ver producto';
    p.affiliate_url = String(raw.affiliate_url || '');
    p.featured = !!raw.featured;
    p.review = String(raw.review || '');
    p.seo_title = String(raw.seo_title || '');
    p.seo_description = String(raw.seo_description || '');
    return p;
  }

  /* ================= 4. Borrador en localStorage ================= */

  function saveDraft() {
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify({
        savedAt: new Date().toISOString(),
        products: state.products
      }));
    } catch (e) {
      /* localStorage no disponible: se sigue sin borrador. */
    }
  }

  function readDraft() {
    try {
      var raw = localStorage.getItem(DRAFT_KEY);
      if (!raw) return null;
      var draft = JSON.parse(raw);
      if (!draft || !Array.isArray(draft.products)) return null;
      return draft;
    } catch (e) {
      return null;
    }
  }

  function checkDraft() {
    var draft = readDraft();
    var notice = $('draft-notice');
    if (!draft) {
      notice.hidden = true;
      return;
    }
    var date = new Date(draft.savedAt);
    $('draft-date').textContent = isNaN(date.getTime())
      ? 'fecha desconocida'
      : date.toLocaleString('es-ES');
    notice.hidden = false;
  }

  function discardDraft() {
    try { localStorage.removeItem(DRAFT_KEY); } catch (e) {}
    $('draft-notice').hidden = true;
    showMsg('Borrador descartado. Se mantiene el catálogo cargado actualmente.', 'info');
  }

  function restoreDraft() {
    var draft = readDraft();
    if (!draft) return;
    state.products = draft.products.map(function (raw) { return normalizeProduct(raw, false); });
    $('draft-notice').hidden = true;
    renderAll();
    showMsg('Borrador restaurado (' + state.products.length + ' productos). Recuerda exportar cuando termines.', 'ok');
  }

  /* ================= 5. Tabla de productos ================= */

  function matchesFilter(p) {
    if (!state.filter) return true;
    var q = state.filter.toLowerCase();
    return (
      p.id.toLowerCase().indexOf(q) !== -1 ||
      p.name.toLowerCase().indexOf(q) !== -1 ||
      categoryLabel(p.category).toLowerCase().indexOf(q) !== -1 ||
      p.category.toLowerCase().indexOf(q) !== -1
    );
  }

  function renderTable() {
    var tbody = $('products-tbody');
    var list = state.products.filter(matchesFilter);
    var html = list.map(function (p) {
      var pending = isPending(p.affiliate_url);
      return '<tr>' +
        '<td><code>' + esc(p.id) + '</code></td>' +
        '<td><strong>' + esc(p.name) + '</strong></td>' +
        '<td>' + esc(categoryLabel(p.category)) + '</td>' +
        '<td>' + esc(p.cta || 'Ver producto') + '</td>' +
        '<td>' + (pending
          ? '<span class="pill pill-pending">⚠ pendiente</span>'
          : '<span class="pill pill-ok">✓ configurado</span>') + '</td>' +
        '<td>' + (p.featured ? '⭐' : '—') + '</td>' +
        '<td class="actions">' +
          '<button type="button" class="btn" data-action="edit" data-id="' + esc(p.id) + '">Editar</button> ' +
          '<button type="button" class="btn btn-danger" data-action="delete" data-id="' + esc(p.id) + '">Eliminar</button>' +
        '</td>' +
      '</tr>';
    }).join('');

    tbody.innerHTML = html || '';
    $('table-empty').hidden = list.length > 0;
    $('products-count').textContent = '· ' + state.products.length +
      (state.filter ? ' (' + list.length + ' coinciden)' : '');
  }

  /* ================= 6. Editor ================= */

  function fillSelect(select, options, current, emptyLabel) {
    select.innerHTML = '';
    if (emptyLabel !== undefined) {
      var opt0 = document.createElement('option');
      opt0.value = '';
      opt0.textContent = emptyLabel;
      select.appendChild(opt0);
    }
    options.forEach(function (o) {
      var value = typeof o === 'string' ? o : o.slug;
      var label = typeof o === 'string' ? (o || emptyLabel || '—') : o.label;
      var opt = document.createElement('option');
      opt.value = value;
      opt.textContent = label;
      select.appendChild(opt);
    });
    select.value = current || '';
  }

  function initEditorStatics() {
    fillSelect($('f-category'), CATEGORIES, '');
    var verdictSel = $('f-verdict');
    verdictSel.innerHTML = '';
    VERDICTS.forEach(function (v, i) {
      var opt = document.createElement('option');
      opt.value = v;
      opt.textContent = v === '' ? '— Sin valoración —' : v;
      verdictSel.appendChild(opt);
    });
    var ctaSel = $('f-cta');
    ctaSel.innerHTML = '';
    CTAS.forEach(function (c) {
      var opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      ctaSel.appendChild(opt);
    });
  }

  /** Convierte un textarea (una línea por elemento) en array. */
  function linesToArray(text) {
    return String(text || '')
      .split('\n')
      .map(function (l) { return l.trim(); })
      .filter(Boolean);
  }

  function checkedValues(containerId) {
    var out = [];
    var boxes = document.querySelectorAll('#' + containerId + ' input[type="checkbox"]:checked');
    for (var i = 0; i < boxes.length; i++) out.push(boxes[i].value);
    return out;
  }

  function setCheckedValues(containerId, values) {
    var boxes = document.querySelectorAll('#' + containerId + ' input[type="checkbox"]');
    for (var i = 0; i < boxes.length; i++) {
      boxes[i].checked = values.indexOf(boxes[i].value) !== -1;
    }
  }

  function newProductDefaults() {
    return {
      id: '', name: '', category: '', image: '', image_alt: '',
      summary: '', features: [], pros: [], cons: [], ideal_for: '',
      dog_size: [], dog_age: [], verdict: '', cta: 'Ver producto',
      affiliate_url: '[ENLACE_AFILIADO]', featured: false, review: '',
      seo_title: '', seo_description: ''
    };
  }

  function openEditor(id) {
    var p = id
      ? state.products.filter(function (x) { return x.id === id; })[0]
      : null;
    state.editingId = id || null;
    $('editor-title').textContent = p ? 'Editar producto: ' + p.name : 'Nuevo producto';

    var d = p || newProductDefaults();
    $('f-id').value = d.id || '';
    $('f-id').disabled = !!p; // el ID no se cambia al editar (es la clave)
    $('f-name').value = d.name || '';
    $('f-category').value = d.category || '';
    $('f-review').value = d.review || '';
    $('f-summary').value = d.summary || '';
    $('f-image').value = d.image || '';
    $('f-image_alt').value = d.image_alt || '';
    $('f-features').value = (d.features || []).join('\n');
    $('f-pros').value = (d.pros || []).join('\n');
    $('f-cons').value = (d.cons || []).join('\n');
    $('f-ideal_for').value = d.ideal_for || '';
    setCheckedValues('f-dog_size', d.dog_size || []);
    setCheckedValues('f-dog_age', d.dog_age || []);
    $('f-verdict').value = d.verdict || '';
    $('f-featured').checked = !!d.featured;
    $('f-affiliate_url').value = d.affiliate_url || '';
    $('f-cta').value = d.cta || 'Ver producto';
    $('f-seo_title').value = d.seo_title || '';
    $('f-seo_description').value = d.seo_description || '';
    showFormErrors([]);

    $('editor').hidden = false;
    $('editor').scrollIntoView({ behavior: 'smooth', block: 'start' });
    $('f-name').focus();
  }

  function closeEditor() {
    $('editor').hidden = true;
    state.editingId = null;
    showFormErrors([]);
  }

  function collectForm() {
    return normalizeProduct({
      id: $('f-id').value.trim(),
      name: $('f-name').value.trim(),
      category: $('f-category').value,
      image: $('f-image').value.trim(),
      image_alt: $('f-image_alt').value.trim(),
      summary: $('f-summary').value.trim(),
      features: linesToArray($('f-features').value),
      pros: linesToArray($('f-pros').value),
      cons: linesToArray($('f-cons').value),
      ideal_for: $('f-ideal_for').value.trim(),
      dog_size: checkedValues('f-dog_size'),
      dog_age: checkedValues('f-dog_age'),
      verdict: $('f-verdict').value,
      cta: $('f-cta').value,
      affiliate_url: $('f-affiliate_url').value.trim(),
      featured: $('f-featured').checked,
      review: $('f-review').value.trim(),
      seo_title: $('f-seo_title').value.trim(),
      seo_description: $('f-seo_description').value.trim()
    }, false);
  }

  /** Validación básica antes de guardar. */
  function validateProduct(p) {
    var errors = [];
    if (!p.id) {
      errors.push('El campo «ID» es obligatorio.');
    } else if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(p.id)) {
      errors.push('El ID solo puede contener minúsculas, números y guiones (p. ej. «kong-classic»).');
    } else if (state.products.some(function (x) {
      return x.id === p.id && x.id !== state.editingId;
    })) {
      errors.push('Ya existe otro producto con el ID «' + p.id + '».');
    }
    if (!p.name) errors.push('El campo «Nombre» es obligatorio.');
    if (!p.category) errors.push('Elige una «Categoría».');
    if (!p.affiliate_url) {
      errors.push('El campo «URL de afiliado» es obligatorio (puedes dejar el marcador [ENLACE_AFILIADO]).');
    }
    return errors;
  }

  function saveProduct() {
    var p = collectForm();
    var errors = validateProduct(p);
    if (errors.length) {
      showFormErrors(errors);
      return;
    }
    if (state.editingId) {
      // Actualiza el existente (conserva campos extra desconocidos).
      for (var i = 0; i < state.products.length; i++) {
        if (state.products[i].id === state.editingId) {
          var merged = {};
          Object.keys(state.products[i]).forEach(function (k) { merged[k] = state.products[i][k]; });
          Object.keys(p).forEach(function (k) { merged[k] = p[k]; });
          state.products[i] = merged;
          break;
        }
      }
      showMsg('Producto «' + p.name + '» actualizado.', 'ok');
    } else {
      state.products.push(p);
      showMsg('Producto «' + p.name + '» creado.', 'ok');
    }
    saveDraft();
    closeEditor();
    renderAll();
  }

  function deleteProduct(id) {
    var p = state.products.filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    if (!window.confirm('¿Eliminar el producto «' + p.name + '» (' + p.id + ')? Esta acción no se puede deshacer.')) {
      return;
    }
    state.products = state.products.filter(function (x) { return x.id !== id; });
    saveDraft();
    renderAll();
    showMsg('Producto «' + p.name + '» eliminado.', 'ok');
  }

  /* ================= 7. Informe de afiliados ================= */

  function pendingProducts() {
    return state.products.filter(function (p) { return isPending(p.affiliate_url); });
  }

  function renderReport() {
    var body = $('report-body');
    var list = pendingProducts();

    var badge = $('report-count');
    badge.hidden = list.length === 0;
    badge.textContent = list.length;

    if (!list.length) {
      body.innerHTML = '<p class="msg msg-ok" style="margin:0">✓ Todos los productos tienen su URL de afiliado configurada.</p>';
      return;
    }
    var html = '<p class="muted">Estos productos aún usan el marcador <code>[ENLACE_AFILIADO]</code> o no tienen URL. Pega tu enlace real editando cada producto.</p>' +
      '<div class="table-scroll"><table><thead><tr><th>ID</th><th>Nombre</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>' +
      list.map(function (p) {
        var estado = !p.affiliate_url ? 'Vacío' : 'Contiene [ENLACE_AFILIADO]';
        return '<tr><td><code>' + esc(p.id) + '</code></td>' +
          '<td><strong>' + esc(p.name) + '</strong></td>' +
          '<td><span class="pill pill-pending">⚠ ' + esc(estado) + '</span></td>' +
          '<td class="actions"><button type="button" class="btn" data-action="edit" data-id="' + esc(p.id) + '">Editar</button></td></tr>';
      }).join('') +
      '</tbody></table></div>';
    body.innerHTML = html;
  }

  function toggleReport(force) {
    var section = $('report-section');
    var show = force !== undefined ? force : section.hidden;
    if (show) renderReport();
    section.hidden = !show;
    if (show) section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ================= 8. Exportar / importar ================= */

  function exportJSON() {
    var blob = new Blob(
      [JSON.stringify(state.products, null, 2)],
      { type: 'application/json' }
    );
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'products.json';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 200);
    showMsg(
      'Archivo products.json descargado. Sustituye el archivo en data/, ejecuta python3 build.py y sube dist/ para publicar los cambios.',
      'ok'
    );
  }

  function importJSON(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var data = JSON.parse(reader.result);
        if (!Array.isArray(data)) throw new Error('el archivo debe contener un array JSON');
        var normalized = [];
        var errors = [];
        data.forEach(function (raw, i) {
          try {
            normalized.push(normalizeProduct(raw, true));
          } catch (err) {
            errors.push('Elemento ' + (i + 1) + ': ' + err.message);
          }
        });
        if (errors.length) {
          showMsg('No se pudo importar:\n' + errors.slice(0, 8).join('\n'), 'error');
          return;
        }
        state.products = normalized;
        saveDraft();
        closeEditor();
        renderAll();
        showMsg('Importados ' + normalized.length + ' productos. Revisa los cambios y exporta cuando esté listo.', 'ok');
      } catch (err) {
        showMsg('Archivo no válido: ' + err.message, 'error');
      }
    };
    reader.onerror = function () {
      showMsg('No se pudo leer el archivo.', 'error');
    };
    reader.readAsText(file);
  }

  /* ================= 9. Render general y eventos ================= */

  function renderAll() {
    renderTable();
    renderReportBadgeOnly();
  }

  /** Actualiza solo el contador del informe sin abrirlo. */
  function renderReportBadgeOnly() {
    var n = pendingProducts().length;
    var badge = $('report-count');
    badge.hidden = n === 0;
    badge.textContent = n;
    // Si el informe está abierto, refresca su contenido.
    if (!$('report-section').hidden) renderReport();
  }

  function bindEvents() {
    $('btn-new').addEventListener('click', function () { openEditor(null); });
    $('btn-export').addEventListener('click', exportJSON);
    $('btn-report').addEventListener('click', function () { toggleReport(); });
    $('report-close').addEventListener('click', function () { toggleReport(false); });

    $('import-file').addEventListener('change', function (e) {
      if (e.target.files && e.target.files[0]) importJSON(e.target.files[0]);
      e.target.value = ''; // permite importar el mismo archivo dos veces
    });

    $('draft-restore').addEventListener('click', restoreDraft);
    $('draft-discard').addEventListener('click', discardDraft);

    $('product-search').addEventListener('input', function (e) {
      state.filter = e.target.value.trim();
      renderTable();
    });

    // Delegación: botones Editar / Eliminar (tabla e informe).
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-action]');
      if (!btn) return;
      var id = btn.getAttribute('data-id');
      if (btn.getAttribute('data-action') === 'edit') {
        toggleReport(false);
        openEditor(id);
      } else if (btn.getAttribute('data-action') === 'delete') {
        deleteProduct(id);
      }
    });

    $('product-form').addEventListener('submit', function (e) {
      e.preventDefault();
      saveProduct();
    });
    $('btn-cancel').addEventListener('click', closeEditor);

    // Escape cierra el editor.
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !$('editor').hidden) closeEditor();
    });
  }

  /* ================= 10. Init ================= */

  initEditorStatics();
  bindEvents();
  loadProducts();
})();
