/* ============================================================
 * CaninoPick · main.js
 * ------------------------------------------------------------
 * JavaScript del sitio público. Vanilla JS, sin dependencias.
 * El generador lo carga con `defer`.
 *
 * Incluye:
 *  1. Toggle del menú móvil
 *  2. Filtros de productos por chips
 *  3. Quiz "Encuentra productos para tu perro"
 *  4. Buscador interno (página /buscar/)
 *  5. Formulario de newsletter
 *  6. Botón "volver arriba" y año dinámico
 *
 * Todas las funciones tienen guards: si el elemento no existe
 * en la página actual, no hacen nada (sin errores en consola).
 * ============================================================ */
(function () {
  'use strict';

  /* ================= 0. Utilidades ================= */

  /** Atajo para querySelector. */
  function $(selector, context) {
    return (context || document).querySelector(selector);
  }

  /** Atajo para querySelectorAll devuelto como array. */
  function $$(selector, context) {
    return Array.prototype.slice.call((context || document).querySelectorAll(selector));
  }

  /** Minúsculas y sin tildes: para comparar textos en español. */
  function normalizeText(str) {
    return String(str || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, ''); // elimina los signos diacríticos
  }

  /* ================= 1. Menú móvil ================= */

  function initNavToggle() {
    var toggle = $('#nav-toggle');
    var nav = $('#site-nav');
    if (!toggle || !nav) return;

    function setOpen(open) {
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      nav.classList.toggle('is-open', open);
    }

    toggle.addEventListener('click', function () {
      setOpen(toggle.getAttribute('aria-expanded') !== 'true');
    });

    // Cierra el menú con la tecla Escape y devuelve el foco al botón.
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        setOpen(false);
        toggle.focus();
      }
    });

    // Cierra el menú al pulsar un enlace (útil en móvil).
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a')) setOpen(false);
    });
  }

  /* ================= 2. Filtros por chips =================
   * Chips: .chip[data-filter-group][data-filter-value]
   * Tarjetas: .js-filterable[data-tamano][data-edad][data-categoria]
   * (valores separados por espacios). Los grupos combinan con AND;
   * dentro de un grupo, varios valores seleccionados combinan con OR.
   * El chip con data-filter-value="todos" resetea su grupo.
   */
  function initFilters() {
    var chips = $$('.chip[data-filter-group][data-filter-value]');
    var cards = $$('.js-filterable');
    if (!chips.length || !cards.length) return;

    // Estado: { nombreDelGrupo: Set(valores seleccionados) }
    var state = {};
    chips.forEach(function (chip) {
      var group = chip.getAttribute('data-filter-group');
      if (!state[group]) state[group] = new Set();
      // Respeta el estado inicial que venga del HTML.
      if (chip.getAttribute('aria-pressed') === 'true') {
        state[group].add(chip.getAttribute('data-filter-value').toLowerCase());
      } else {
        chip.setAttribute('aria-pressed', 'false');
      }
    });

    // Mensaje amable cuando ningún producto coincide con los filtros.
    var emptyMsg = $('.filter-empty');
    if (!emptyMsg) {
      emptyMsg = document.createElement('p');
      emptyMsg.className = 'filter-empty';
      emptyMsg.hidden = true;
      emptyMsg.textContent =
        'Ningún producto coincide con esos filtros. Prueba a quitar alguno.';
      cards[0].parentElement.appendChild(emptyMsg);
    }

    function applyFilters() {
      var visible = 0;
      cards.forEach(function (card) {
        var show = true;
        Object.keys(state).forEach(function (group) {
          var selected = state[group];
          if (!selected.size) return; // grupo sin filtro: no restringe
          var attr = card.getAttribute('data-' + group) || '';
          var values = attr.toLowerCase().split(/\s+/).filter(Boolean);
          var match = false;
          selected.forEach(function (v) {
            if (values.indexOf(v) !== -1) match = true;
          });
          if (!match) show = false;
        });
        card.hidden = !show;
        if (show) visible++;
      });
      emptyMsg.hidden = visible > 0;
    }

    chips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        var group = chip.getAttribute('data-filter-group');
        var value = chip.getAttribute('data-filter-value').toLowerCase();

        if (value === 'todos') {
          // "Todos" resetea el grupo completo.
          state[group] = new Set();
          $$('.chip[data-filter-group="' + group + '"]').forEach(function (c) {
            c.setAttribute('aria-pressed', c === chip ? 'true' : 'false');
          });
        } else {
          var pressed = chip.getAttribute('aria-pressed') === 'true';
          chip.setAttribute('aria-pressed', pressed ? 'false' : 'true');
          if (pressed) state[group].delete(value);
          else state[group].add(value);
          // Si hay selección manual, el chip "todos" del grupo se desactiva.
          var todos = $('.chip[data-filter-group="' + group + '"][data-filter-value="todos"]');
          if (todos) todos.setAttribute('aria-pressed', 'false');
        }
        applyFilters();
      });
    });

    applyFilters();
  }

  /* ================= 3. Quiz =================
   * Estructura (la genera build.py):
   *   #quiz
   *     .quiz__step[data-step="1|2|3"] con botones button[data-value]
   *       (data-next opcional para saltos no secuenciales)
   *     #quiz-result (oculto hasta el final)
   * Pasos: 1 = tamaño, 2 = edad, 3 = necesidad.
   */

  /** Etiquetas legibles para los valores del quiz. */
  var QUIZ_LABELS = {
    tamano: { pequeno: 'pequeño', mediano: 'mediano', grande: 'grande' },
    edad: { cachorro: 'cachorro', adulto: 'adulto', senior: 'senior' },
    necesidad: {
      dormir: 'dormir',
      jugar: 'jugar',
      pasear: 'pasear',
      comer: 'comer',
      viajar: 'viajar',
      higiene: 'higiene',
      entrenamiento: 'entrenamiento'
    }
  };

  /**
   * Mapeo necesidad → recomendaciones con URLs reales del sitio.
   * `porTamano` añade la comparativa específica cuando el tamaño
   * lo admite (grande / pequeño).
   */
  var QUIZ_LINKS = {
    dormir: {
      enlaces: [
        { texto: 'Camas para perros', url: '/camas-para-perros/', desc: 'Todos los tipos de camas: ortopédicas, lavables, para cachorros y más.' },
        { texto: 'Comparativa: las mejores camas para perros', url: '/mejores-camas-para-perros/', desc: 'Nuestra selección comparada para ayudarte a elegir bien.' }
      ],
      porTamano: {
        grande: [{ texto: 'Camas para perros grandes', url: '/mejores-camas-para-perros/', desc: 'En la comparativa puedes ver las opciones ideales para razas grandes.' }],
        pequeno: [{ texto: 'Camas para perros pequeños', url: '/mejores-camas-para-perros/', desc: 'En la comparativa puedes ver las opciones ideales para perros pequeños.' }]
      }
    },
    jugar: {
      enlaces: [
        { texto: 'Juguetes para perros', url: '/juguetes-para-perros/', desc: 'Juguetes resistentes, interactivos y para todas las edades.' },
        { texto: 'Comparativa: los mejores juguetes para perros', url: '/mejores-juguetes-para-perros/', desc: 'Nuestra selección comparada según tipo de juego.' }
      ],
      porTamano: {
        grande: [{ texto: 'Juguetes para perros grandes', url: '/mejores-juguetes-para-perros/', desc: 'En la comparativa puedes ver juguetes de tamaño y resistencia adecuados.' }],
        pequeno: [{ texto: 'Juguetes para perros pequeños', url: '/mejores-juguetes-para-perros/', desc: 'En la comparativa puedes ver juguetes ligeros y fáciles de agarrar.' }]
      }
    },
    pasear: {
      enlaces: [
        { texto: 'Correas y arneses para perros', url: '/arneses-para-perros/', desc: 'Arnéses cómodos y correas seguras para paseos tranquilos.' },
        { texto: 'Comparativa: los mejores arneses para perros', url: '/mejores-arneses-para-perros/', desc: 'Nuestra selección comparada para elegir el arnés ideal.' }
      ]
    },
    comer: {
      enlaces: [
        { texto: 'Comederos y bebederos para perros', url: '/comederos-para-perros/', desc: 'Comederos lentos, automáticos y bebederos para cada necesidad.' },
        { texto: 'Comparativa: los mejores comederos para perros', url: '/mejores-comederos-para-perros/', desc: 'Nuestra selección comparada para una alimentación cómoda.' }
      ]
    },
    viajar: {
      enlaces: [
        { texto: 'Accesorios para viajar con perros', url: '/viajar-con-perros/', desc: 'Transportines, cinturones y accesorios para viajar seguro.' },
        { texto: 'Guía: los mejores accesorios para viajar con perros', url: '/mejores-accesorios-para-viajar-con-perros/', desc: 'Nuestra selección para que viajar juntos sea fácil.' }
      ]
    },
    higiene: {
      enlaces: [
        { texto: 'Higiene y cuidado para perros', url: '/higiene-para-perros/', desc: 'Champús, cepillos y productos para mantenerlo limpio y sano.' },
        { texto: 'Explorar los mejores productos para perros', url: '/mejores-productos-para-perros/', desc: 'Todas nuestras comparativas en un solo lugar.' }
      ]
    },
    entrenamiento: {
      enlaces: [
        { texto: 'Productos de entrenamiento para perros', url: '/entrenamiento-para-perros/', desc: 'Premios, clickers y ayudas para educar con refuerzo positivo.' },
        { texto: 'Explorar los mejores productos para perros', url: '/mejores-productos-para-perros/', desc: 'Todas nuestras comparativas en un solo lugar.' }
      ]
    }
  };

  function initQuiz() {
    var quiz = $('#quiz');
    if (!quiz) return;

    var steps = $$('.quiz__step[data-step]', quiz).sort(function (a, b) {
      return Number(a.getAttribute('data-step')) - Number(b.getAttribute('data-step'));
    });
    var result = $('#quiz-result');
    if (!steps.length || !result) return;

    // Clave de respuesta según el orden de los pasos.
    var KEYS = ['tamano', 'edad', 'necesidad'];
    var answers = {};
    var current = 0;

    // Progreso visible ("Paso X de 3").
    var progress = $('.quiz__progress', quiz);
    if (!progress) {
      progress = document.createElement('p');
      progress.className = 'quiz__progress';
      quiz.insertBefore(progress, quiz.firstChild);
    }

    function stepKey(i) {
      return KEYS[i] || ('paso' + (i + 1));
    }

    function updateProgress() {
      progress.textContent = 'Paso ' + (current + 1) + ' de ' + steps.length;
    }

    function showStep(i) {
      current = i;
      steps.forEach(function (s, idx) {
        s.hidden = idx !== i;
      });
      result.hidden = true;
      updateProgress();
      var heading = steps[i].querySelector('h2, h3');
      if (heading) {
        heading.setAttribute('tabindex', '-1');
        heading.focus({ preventScroll: true });
      }
    }

    // Botón "Atrás" en los pasos 2 y 3.
    steps.forEach(function (step, idx) {
      if (idx === 0) return;
      if ($('.quiz__back', step)) return; // no duplicar si ya existe
      var back = document.createElement('button');
      back.type = 'button';
      back.className = 'quiz__back btn btn--secondary';
      back.textContent = '← Atrás';
      back.addEventListener('click', function () {
        showStep(idx - 1);
      });
      step.appendChild(back);
    });

    // Opciones de cada paso.
    steps.forEach(function (step, idx) {
      $$('button[data-value]', step).forEach(function (btn) {
        // Evita doble binding si el script se evaluara dos veces.
        if (btn.__quizBound) return;
        btn.__quizBound = true;
        btn.addEventListener('click', function () {
          answers[stepKey(idx)] = btn.getAttribute('data-value');
          var next = btn.getAttribute('data-next');
          if (next === 'result' || idx === steps.length - 1) {
            showResult();
          } else if (next) {
            var target = -1;
            steps.forEach(function (s, si) {
              if (s.getAttribute('data-step') === next) target = si;
            });
            showStep(target !== -1 ? target : idx + 1);
          } else {
            showStep(idx + 1);
          }
        });
      });
    });

    /** Construye la lista de recomendaciones según las respuestas. */
    function buildRecommendations() {
      var necesidad = answers.necesidad;
      var tamano = answers.tamano;
      var edad = answers.edad;
      var links = [];
      var cfg = QUIZ_LINKS[necesidad];

      if (cfg) {
        links = links.concat(cfg.enlaces);
        // Ajuste por tamaño: añade la comparativa específica si existe.
        if (tamano && cfg.porTamano && cfg.porTamano[tamano]) {
          links = links.concat(cfg.porTamano[tamano]);
        }
      } else {
        // Necesidad no reconocida: al menos el hub de comparativas.
        links.push({
          texto: 'Explorar los mejores productos para perros',
          url: '/mejores-productos-para-perros/',
          desc: 'Todas nuestras comparativas en un solo lugar.'
        });
      }

      // Los cachorros tienen su propia sección.
      if (edad === 'cachorro') {
        links.push({
          texto: 'Productos para cachorros',
          url: '/productos-para-cachorros/',
          desc: 'Todo lo esencial para los primeros meses de tu cachorro.'
        });
      }

      // Evita URLs duplicadas.
      var seen = {};
      return links.filter(function (l) {
        if (seen[l.url]) return false;
        seen[l.url] = true;
        return true;
      });
    }

    function showResult() {
      steps.forEach(function (s) {
        s.hidden = true;
      });
      progress.textContent = '¡Listo! Estas son tus recomendaciones';

      // Limpia el resultado anterior.
      while (result.firstChild) result.removeChild(result.firstChild);

      var title = document.createElement('h2');
      title.className = 'quiz__result-title';
      title.textContent = 'Recomendaciones para tu perro';
      result.appendChild(title);

      var summary = document.createElement('p');
      summary.className = 'quiz__result-summary';
      var parts = [];
      if (answers.tamano && QUIZ_LABELS.tamano[answers.tamano]) {
        parts.push('Tamaño: ' + QUIZ_LABELS.tamano[answers.tamano]);
      }
      if (answers.edad && QUIZ_LABELS.edad[answers.edad]) {
        parts.push('Edad: ' + QUIZ_LABELS.edad[answers.edad]);
      }
      if (answers.necesidad && QUIZ_LABELS.necesidad[answers.necesidad]) {
        parts.push('Necesidad: ' + QUIZ_LABELS.necesidad[answers.necesidad]);
      }
      summary.textContent = parts.join(' · ') + '. Esto es lo que te recomendamos explorar:';
      result.appendChild(summary);

      var list = document.createElement('ul');
      list.className = 'quiz__result-list';
      buildRecommendations().forEach(function (link) {
        var li = document.createElement('li');
        var a = document.createElement('a');
        a.href = link.url;
        a.textContent = link.texto;
        li.appendChild(a);
        if (link.desc) {
          var d = document.createElement('p');
          d.textContent = link.desc;
          li.appendChild(d);
        }
        list.appendChild(li);
      });
      result.appendChild(list);

      var restart = document.createElement('button');
      restart.type = 'button';
      restart.className = 'quiz__restart btn btn--secondary';
      restart.textContent = '↺ Empezar de nuevo';
      restart.addEventListener('click', function () {
        answers = {};
        showStep(0);
      });
      result.appendChild(restart);

      result.hidden = false;
      result.scrollIntoView({ behavior: 'smooth', block: 'start' });
      title.setAttribute('tabindex', '-1');
      title.focus({ preventScroll: true });
    }

    showStep(0);
  }

  /* ================= 4. Buscador =================
   * Página /buscar/: lee /search.json
   *   [{ title, url, type, excerpt, category }]
   * type: producto | comparativa | guia | articulo | pagina
   * Filtra en vivo por #search-input (título + excerpt, mín. 2
   * caracteres) y pinta #search-results agrupado por tipo.
   */
  function initSearch() {
    var input = $('#search-input');
    var results = $('#search-results');
    if (!input || !results) return;

    var GROUPS = [
      { type: 'producto', title: 'Productos' },
      { type: 'comparativa', title: 'Comparativas' },
      { type: 'guia', title: 'Guías' },
      { type: 'articulo', title: 'Artículos' },
      { type: 'pagina', title: 'Páginas' }
    ];

    var index = null;
    var failed = false;

    function renderMessage(text, cls) {
      results.innerHTML = '';
      var p = document.createElement('p');
      p.className = cls || 'search-hint';
      p.textContent = text;
      results.appendChild(p);
    }

    function doSearch() {
      var q = input.value.trim();
      results.innerHTML = '';

      if (q.length < 2) {
        renderMessage('Escribe al menos 2 caracteres para buscar.');
        return;
      }
      if (failed) {
        renderMessage(
          'No se pudo cargar el índice de búsqueda. Comprueba tu conexión e inténtalo de nuevo.',
          'search-empty'
        );
        return;
      }
      if (!index) {
        renderMessage('Buscando…');
        return;
      }

      var nq = normalizeText(q);
      var hits = index.filter(function (entry) {
        return (
          normalizeText(entry.title).indexOf(nq) !== -1 ||
          normalizeText(entry.excerpt).indexOf(nq) !== -1
        );
      });

      // Contador de resultados.
      var count = document.createElement('p');
      count.className = 'search-count';
      if (hits.length === 0) {
        count.textContent = 'No hemos encontrado resultados para «' + q + '».';
      } else {
        count.textContent =
          hits.length + (hits.length === 1 ? ' resultado' : ' resultados') +
          ' para «' + q + '»';
      }
      results.appendChild(count);

      // Estado vacío amable.
      if (hits.length === 0) {
        var empty = document.createElement('div');
        empty.className = 'search-empty';
        var p1 = document.createElement('p');
        p1.textContent = 'Prueba con otra palabra, por ejemplo «cama», «juguete» o «arnés».';
        var p2 = document.createElement('p');
        p2.textContent = 'También puedes explorar ';
        var link = document.createElement('a');
        link.href = '/mejores-productos-para-perros/';
        link.textContent = 'nuestras comparativas de productos';
        p2.appendChild(link);
        p2.appendChild(document.createTextNode('.'));
        empty.appendChild(p1);
        empty.appendChild(p2);
        results.appendChild(empty);
        return;
      }

      // Resultados agrupados por tipo.
      GROUPS.forEach(function (g) {
        var items = hits.filter(function (h) {
          return h.type === g.type;
        });
        if (!items.length) return;

        var section = document.createElement('section');
        section.className = 'result-group';
        section.setAttribute('aria-label', g.title);

        var heading = document.createElement('h2');
        heading.className = 'result-group__title';
        heading.textContent = g.title;
        section.appendChild(heading);

        var ul = document.createElement('ul');
        ul.className = 'result-group__list';
        items.forEach(function (item) {
          var li = document.createElement('li');
          var a = document.createElement('a');
          a.href = item.url;
          a.textContent = item.title;
          li.appendChild(a);
          if (item.excerpt) {
            var ex = document.createElement('p');
            ex.textContent = item.excerpt;
            li.appendChild(ex);
          }
          ul.appendChild(li);
        });
        section.appendChild(ul);
        results.appendChild(section);
      });
    }

    input.addEventListener('input', doSearch);

    fetch('/search.json')
      .then(function (resp) {
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        return resp.json();
      })
      .then(function (data) {
        index = Array.isArray(data) ? data : [];
        doSearch();
      })
      .catch(function () {
        failed = true;
        doSearch();
      });
  }

  /* ================= 5. Newsletter ================= */

  function initNewsletter() {
    var form = $('#newsletter-form');
    if (!form) return;

    var msg = $('.form-msg', form);
    var emailInput = form.querySelector('input[type="email"]');

    function show(text, ok) {
      if (!msg) return;
      msg.textContent = text;
      msg.classList.toggle('form-msg--success', !!ok);
      msg.classList.toggle('form-msg--error', !ok);
    }

    form.addEventListener('submit', function (e) {
      var email = emailInput ? emailInput.value.trim() : '';
      var valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);

      if (!valid) {
        e.preventDefault();
        show('Por favor, escribe un correo electrónico válido.', false);
        if (emailInput) emailInput.focus();
        return;
      }

      var action = form.getAttribute('data-action');
      if (action) {
        // Hay acción real configurada: se deja el envío nativo del formulario.
        form.setAttribute('action', action);
        return;
      }

      // Sin backend: se simula la suscripción.
      e.preventDefault();
      show('¡Gracias por suscribirte! Revisa tu correo para confirmar la suscripción.', true);
      form.reset();
    });
  }

  /* ================= 6. Volver arriba y año ================= */

  function initBackToTop() {
    var btn = $('.js-back-to-top');
    if (!btn) return;

    function onScroll() {
      btn.classList.toggle('is-visible', window.scrollY > 600);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    btn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  function initYear() {
    var el = $('#year');
    if (el) el.textContent = String(new Date().getFullYear());
  }

  /* ================= Init ================= */

  initNavToggle();
  initFilters();
  initQuiz();
  initSearch();
  initNewsletter();
  initBackToTop();
  initYear();
})();
